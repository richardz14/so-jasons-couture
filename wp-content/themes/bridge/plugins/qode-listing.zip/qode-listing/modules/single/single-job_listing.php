<?php
get_header();
qode_listing_single_listing();
get_footer();