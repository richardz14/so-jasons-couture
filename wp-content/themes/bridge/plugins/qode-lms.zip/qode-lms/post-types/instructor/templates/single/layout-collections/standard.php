<div class="qode-instructor-single-info-holder">
	<div class="qode-grid-row">
		<div class="qode-ts-info-holder qode-grid-col-3">
			<?php qode_lms_get_cpt_single_module_template_part( 'templates/single/parts/image', 'instructor', '', $params ); ?>
			<?php qode_lms_get_cpt_single_module_template_part( 'templates/single/parts/name', 'instructor', '', $params ); ?>
			<?php qode_lms_get_cpt_single_module_template_part( 'templates/single/parts/title', 'instructor', '', $params ); ?>
			<?php qode_lms_get_cpt_single_module_template_part( 'templates/single/parts/vita', 'instructor', '', $params ); ?>
			<?php qode_lms_get_cpt_single_module_template_part( 'templates/single/parts/social', 'instructor', '', $params ); ?>
			<?php qode_lms_get_cpt_single_module_template_part( 'templates/single/parts/email', 'instructor', '', $params ); ?>
			<?php qode_lms_get_cpt_single_module_template_part( 'templates/single/parts/resume', 'instructor', '', $params ); ?>
		</div>
		<div class="qode-ts-content-holder qode-grid-col-9">
			<?php qode_lms_get_cpt_single_module_template_part( 'templates/single/parts/tabs', 'instructor', '', $params ); ?>
		</div>
	</div>
</div>