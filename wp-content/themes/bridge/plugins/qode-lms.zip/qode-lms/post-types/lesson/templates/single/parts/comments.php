<?php

if ( qode_show_comments() ) {
	comments_template( '', true );
}