<?php

include_once QODE_NEWS_SHORTCODES_PATH.'/video-layout1/functions.php';
include_once QODE_NEWS_SHORTCODES_PATH.'/video-layout1/video-layout1.php';