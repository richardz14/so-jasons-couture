<?php

require_once QODE_NEWS_REACTIONS_PATH.'/functions.php';
require_once QODE_NEWS_REACTIONS_PATH.'/reactions-custom-fields.php';